#!/usr/bin/env python3
"""Exporta el proyecto conservando carpetas y excluyendo credenciales.

Ejecutar desde la raíz: python3 scripts/package-project.py
No depende de ningún paquete adicional.
"""

from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import hashlib
import json
import os
import re

ROOT = Path(__file__).resolve().parents[1]
DESTINATION = ROOT / 'public' / 'descargas' / 'personal-shopper-vip.zip'

ROOT_FILES = (
    'package.json', 'package-lock.json', 'next-env.d.ts', 'next.config.ts',
    'tsconfig.json', 'postcss.config.mjs', 'eslint.config.mjs', 'drizzle.config.ts',
    'vercel.json', '.gitignore', '.vercelignore', '.env.example',
    'README.md', 'DEPLOYMENT.md',
)
REQUIRED_PATHS = (
    'package.json', 'package-lock.json', 'src/app/page.tsx',
    'src/app/layout.tsx', 'src/app/globals.css', 'src/db/index.ts',
    'src/db/schema.ts', 'src/app/api/health/route.ts',
    'src/app/api/products/route.ts', 'src/app/api/quotes/route.ts',
    'src/app/api/rates/route.ts', 'src/app/api/trm/route.ts',
    'src/app/api/search/route.ts', 'src/app/api/scrape-quote/route.ts',
    'src/app/api/manual-quote/route.ts', 'src/components/ProductCard.tsx',
    'src/components/QuoteBreakdownModal.tsx', 'src/lib/pricing.ts',
)
ALLOWED_DIRS = ('src', 'public/images', 'public/logos', 'scripts', 'tests')
BANNED_PARTS = {'.git', '.vercel', 'node_modules', '.next', '__pycache__', 'descargas'}


def allowed(path: Path) -> bool:
    if path.is_symlink() or not path.is_file():
        return False
    relative = path.relative_to(ROOT)
    if any(part in BANNED_PARTS for part in relative.parts):
        return False
    if path.name.startswith('.env') and relative.as_posix() != '.env.example':
        return False
    if path.suffix in {'.zip', '.log', '.pyc', '.tsbuildinfo'}:
        return False
    return True


def main() -> None:
    for relative in REQUIRED_PATHS:
        if not (ROOT / relative).is_file():
            raise SystemExit(f'Falta un archivo necesario para publicar: {relative}')

    candidates = [ROOT / name for name in ROOT_FILES]
    for directory in ALLOWED_DIRS:
        candidates.extend((ROOT / directory).rglob('*'))
    files = sorted({p for p in candidates if allowed(p)}, key=lambda p: p.relative_to(ROOT).as_posix())
    exported = {p.relative_to(ROOT).as_posix() for p in files}
    missing = set(REQUIRED_PATHS) - exported
    if missing:
        raise SystemExit(f'Exportación incompleta: {sorted(missing)}')

    # Comprobar que ningún secreto conocido del entorno aparezca en los archivos.
    # Los valores se comparan localmente y NUNCA se imprimen ni se guardan en el ZIP.
    environment = dict(os.environ)
    for env_name in ('.env', '.env.local', '.env.production', '.env.production.local'):
        env_file = ROOT / env_name
        if not env_file.is_file():
            continue
        for line in env_file.read_text(encoding='utf-8').splitlines():
            match = re.match(r'^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$', line)
            if match:
                environment.setdefault(match[1], match[2].strip().strip('\"\''))
    secrets = [
        (name, value) for name, value in environment.items()
        if len(value) >= 12
        and not name.startswith('NEXT_PUBLIC_')
        and re.search(r'DATABASE_URL|PASSWORD|SECRET|TOKEN|PRIVATE_KEY|API_KEY|ACCESS_KEY|CREDENTIAL', name)
    ]
    binary_extensions = {'.png', '.jpg', '.jpeg', '.gif', '.webp', '.ico', '.woff', '.woff2'}
    for path in files:
        if path.suffix.lower() in binary_extensions:
            continue
        text = path.read_text(encoding='utf-8', errors='ignore')
        for name, value in secrets:
            if value in text:
                raise SystemExit(f'Exportación detenida: revisa {path.relative_to(ROOT)} (posible secreto de {name}).')

    DESTINATION.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(DESTINATION, 'w', ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            archive.write(path, arcname=path.relative_to(ROOT).as_posix())

    with ZipFile(DESTINATION) as archive:
        if archive.testzip() is not None:
            raise SystemExit('El ZIP no pasó la comprobación de integridad.')
        names = set(archive.namelist())
        assert not any(n == '.env' or n.startswith(('.vercel/', 'node_modules/', '.next/')) for n in names)
        assert set(REQUIRED_PATHS) <= names
        print(json.dumps({
            'archivo': str(DESTINATION.relative_to(ROOT)),
            'archivos': len(names),
            'rutas_de_api': len([n for n in names if n.startswith('src/app/api/') and n.endswith('/route.ts')]),
            'bytes': DESTINATION.stat().st_size,
            'sha256': hashlib.sha256(DESTINATION.read_bytes()).hexdigest(),
            'credenciales_incluidas': False,
            'carpetas_preservadas': True,
        }, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
