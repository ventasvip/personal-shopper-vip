import 'dotenv/config';
import { defineConfig } from 'drizzle-kit';

// La CLI debe usar la misma base que la aplicación, tanto en el entorno local
// como al preparar una base PostgreSQL persistente para Vercel.
const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) {
  throw new Error('Configura DATABASE_URL en el entorno antes de ejecutar Drizzle Kit.');
}

export default defineConfig({
  dialect: 'postgresql',
  schema: './src/db/schema.ts',
  dbCredentials: { url: databaseUrl },
});
