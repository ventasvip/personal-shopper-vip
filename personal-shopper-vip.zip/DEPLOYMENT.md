# Publicación permanente — Personal Shopper V.I.P

## Qué dirección compartir

El dominio previsto es **https://traigalodeusa.com**. Añadirlo a los metadatos del código NO lo activa. Se necesita una publicación de producción operativa y la configuración de DNS del titular.

Al conectar este dominio al mismo proyecto de Vercel, **las actualizaciones del código no cambian la dirección pública**. No hace falta crear una redirección diferente cada día. El servicio permanece disponible mientras el dominio, el hosting y la base de datos sigan activos y dentro de sus límites.

No redirijas tu dominio a una vista previa `e2b.app` de este entorno. Tampoco uses una URL de un despliegue específico protegido por Vercel Authentication para compartir con clientes.

## Estado comprobado (no es una publicación en tu cuenta)

En la revisión de esta solicitud:

- `traigalodeusa.com` usa DNS de GoDaddy, pero no está conectado a la aplicación en Vercel.
- `drizzleconfig-dun.vercel.app` devuelve `404 DEPLOYMENT_NOT_FOUND`.
- `drizzleconfig-6q320qv52-personal-shopper-vip.vercel.app` pide iniciar sesión en Vercel.
- Este entorno no contiene una vinculación ni credenciales autorizadas de la cuenta de Vercel o GoDaddy. Los cambios de este proyecto no se envían automáticamente a aquella publicación.

Por eso no se puede presentar ninguna de esas direcciones como una web permanente ya activada. El titular debe conectar su cuenta/hosting mediante un flujo autorizado, sin enviar contraseñas ni códigos de verificación por chat.

## Error de compilación comprobado en el repositorio

El registro compartido muestra el commit `6f76e91` del repositorio `ventasvip/personal-shopper-vip`. Se consultó su árbol público: `page.tsx`, `layout.tsx`, componentes y utilidades están todos sueltos en la raíz. Faltan las carpetas `src/app`, `src/components`, `src/lib`, `src/db` y las distintas subcarpetas de API. Esto explica el error `Couldn't find any pages or app directory`. No es un problema de DNS ni se resuelve esperando propagación.

El paquete completo se exporta con `python3 scripts/package-project.py`. Sigue `README.md` para reemplazar la carga aplanada conservando las carpetas. En Vercel, **Root Directory debe apuntar a la raíz que contiene `package.json` y la carpeta `src`**, no a `src/app`. Los archivos en `public/descargas` son para descargar el código y no se deben subir al repositorio; están excluidos con `.gitignore` y `.vercelignore`.

## 1. Publicar el proyecto completo en Vercel

1. Sube **todo el proyecto**, incluyendo `package.json`, `src`, `public` y `drizzle.config.ts`, a tu repositorio. No basta con subir el archivo de Drizzle.
2. No subas `.env`, credenciales ni `node_modules`. El proyecto incluye `.gitignore` y `.env.example`. Si un secreto ya se publicó, retirarlo del repositorio no es suficiente: revócalo y reemplázalo en su proveedor.
3. En tu cuenta de Vercel, importa el repositorio y selecciona el framework **Next.js**. Usa un plan que permita el uso comercial que vas a dar al servicio.
4. Selecciona como raíz la carpeta que contiene `package.json` (la raíz de este proyecto). Conserva la configuración automática de salida de Next.js y `npm run build` como comando de compilación.
5. Prepara una **base de datos PostgreSQL persistente** accesible desde Vercel (por ejemplo, un proveedor administrado compatible). La dirección `127.0.0.1` de este entorno no funciona como base de producción en Vercel.
6. En **Settings → Environment Variables**, configura para Production:
   - `DATABASE_URL`: la conexión facilitada por el proveedor de la base, con los requisitos de TLS del proveedor.
   - `NEXT_PUBLIC_SITE_URL`: `https://traigalodeusa.com` (es una dirección pública, no un secreto).
7. Prepara las tablas una vez desde un terminal de confianza conectado a ESA base. Carga allí `DATABASE_URL` de forma segura y ejecuta `npx drizzle-kit push --config=drizzle.config.ts`. Revisa los cambios propuestos y haz copia de seguridad antes de aplicarlos a una base con datos existentes. La configuración ahora lee `DATABASE_URL` en lugar de una conexión local fija.
8. Los artículos iniciales se cargan al consultar el catálogo si está vacío. Las cotizaciones guardadas en otro entorno no se transfieren automáticamente: conserva sus copias de seguridad si necesitas migrarlas.
9. Publica y comprueba que el despliegue termina en **Ready**. Si es Preview, usa **Promote to Production** sobre la versión correcta.
10. En **Settings → Deployment Protection**, permite acceso público al dominio de producción. **Standard Protection** mantiene protegidas las vistas previas y deja públicos los dominios de producción; **All Deployments** también los protege. No publiques secretos ni uses un token de bypass en enlaces para clientes.

## 2. Conectar traigalodeusa.com directamente (recomendado)

1. En el proyecto correcto de Vercel, abre **Settings → Domains → Add Domain**.
2. Añade `traigalodeusa.com` al entorno **Production**.
3. Añade también `www.traigalodeusa.com`. Configura `www` para que redirija al dominio sin `www` desde ese panel, o elige una sola versión principal coherente.
4. Vercel mostrará los registros concretos recomendados para TU proyecto. No copies una IP ni un CNAME de una guía genérica; el CNAME puede ser específico del proyecto.
5. En GoDaddy, abre **Mis productos → traigalodeusa.com → DNS**. Guarda antes una copia de los registros actuales.
6. Configura solo los registros web indicados por Vercel:

| Tipo | Nombre | Valor |
| --- | --- | --- |
| A | @ | La IPv4 exacta indicada por Vercel para tu dominio |
| CNAME | www | El destino exacto indicado por Vercel para tu proyecto |

7. Si Vercel solicita verificar propiedad, añade también el TXT que te indique. No es necesario comprar otro dominio.
8. Revisa conflictos entre registros web anteriores para el mismo nombre y los nuevos. Si había reenvío/forwarding de GoDaddy, revísalo antes de usar una conexión DNS directa. No borres registros de correo: MX, SPF, DKIM y DMARC deben conservarse. No cambies servidores de nombres sin migrar previamente todos los registros que necesites.
9. Espera a que el DNS propague y el panel de Vercel muestre **Valid Configuration** y un certificado HTTPS válido. La propagación y emisión del certificado no son instantáneas ni dependen del código de la app.

Una vez verificado, usa siempre **https://traigalodeusa.com**. Cada despliegue de producción del mismo proyecto actualizará el contenido, no el nombre de dominio.

## Alternativa: mantener GoDaddy como redirección

Si prefieres una redirección en vez de conectar el dominio directamente, usa únicamente el **dominio de producción estable** que aparece en **Settings → Domains** de Vercel, cuando ya funcione sin login. No inventes un nombre `vercel.app` ni copies la URL larga de una versión concreta. Un alias de producción no cambia por publicar una nueva versión en el mismo proyecto.

Para la experiencia más sencilla con HTTPS y la misma dirección visible para tus clientes, se recomienda la conexión directa del apartado anterior, no el reenvío enmascarado por iframe.

## Verificación antes de compartir

- Abrir `https://traigalodeusa.com` en incógnito o desde otro equipo, sin sesión de Vercel. No debe pedir login ni mostrar un error.
- Verificar que la página corresponde a la última versión de Personal Shopper V.I.P.
- `https://traigalodeusa.com/api/health` debe responder `200` y `{"ok":true}`.
- El catálogo y una cotización deben funcionar con la base de producción.
- Probar el enlace enviado por WhatsApp y, si se configuró, la redirección de `www`.
- Tras una actualización de producción, volver a abrir el MISMO dominio para confirmar que conserva su dirección.

## Referencias oficiales

- Vercel: https://vercel.com/docs/domains/working-with-domains/add-a-domain
- Vercel (registros específicos del proyecto): https://vercel.com/docs/domains/troubleshooting
- Vercel (dominio de producción frente a URL de despliegue): https://vercel.com/docs/deployments/generated-urls
- Vercel (protección de acceso): https://vercel.com/docs/deployment-protection
- GoDaddy: https://www.godaddy.com/help/manage-dns-records-680
- Drizzle: https://orm.drizzle.team/docs/drizzle-config-file
