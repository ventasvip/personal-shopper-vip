import { NextResponse } from 'next/server';
import { calculateLandedCop, detectStoreFromUrl } from '@/lib/pricing';
import { toAmazonAffiliateUrl } from '@/lib/amazon-affiliate';
import { getPricingConfig } from '@/lib/trm';
import { extractProductFromUrl } from '@/lib/scraper';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { url, title, priceUsd, weightLbs, imageUrl } = body;
    const priceNum = parseFloat(priceUsd);
    if (!priceUsd || isNaN(priceNum) || priceNum <= 0 || priceNum > 100000) {
      return NextResponse.json({ success: false, error: 'Indica un precio válido en USD (el que ves en la tienda).' }, { status: 400 });
    }
    const weightNum = Math.max(0.5, parseFloat(weightLbs || '2') || 2);
    const config = await getPricingConfig();

    // Si viene URL sin imagen, intentamos extraer la imagen REAL de ese enlace
    let realImage: string | null = imageUrl || null;
    let realTitle: string | null = null;
    if (url && !realImage) {
      try {
        const ex = await extractProductFromUrl(String(url));
        realImage = ex.imageUrl;
        realTitle = ex.title;
      } catch {}
    }

    const landed = calculateLandedCop(priceNum, weightNum, config);
    const storeInfo = url ? detectStoreFromUrl(String(url)) : { storeKey: 'otro', storeName: 'Tienda USA' };
    const safeTitle = (title || realTitle || 'Artículo importado').toString().slice(0, 220);
    const originalStoreUrl = url ? String(url) : null;
    const amazonAffiliateUrl = toAmazonAffiliateUrl(safeTitle, originalStoreUrl);

    return NextResponse.json({
      success: true,
      // Siempre abrir Amazon con la etiqueta de afiliado para ver/comprar el artículo.
      url: amazonAffiliateUrl,
      amazonAffiliateUrl,
      originalStoreUrl,
      store: storeInfo.storeName,
      storeKey: storeInfo.storeKey,
      product: {
        title: safeTitle,
        priceUsd: priceNum,
        imageUrl: realImage, // puede ser null -> la UI muestra placeholder honesto, nunca una foto falsa
        imageIsReal: !!realImage,
        weightLbs: weightNum,
        brand: storeInfo.storeName,
        description: `Artículo cotizado en Personal Shopper V.I.P desde ${storeInfo.storeName}.`,
        stockStatus: 'Precio confirmado por el cliente',
      },
      // Solo TOTAL al cliente
      landed: { totalCop: landed.totalCop, deliveryEstimate: landed.deliveryEstimate },
      trm: config.usdToCop,
      trmSource: config.trmSource,
      note: 'Cotización generada. Precio total puesto en Colombia.',
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message || 'Error' }, { status: 500 });
  }
}
