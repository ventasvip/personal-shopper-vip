import { NextResponse } from 'next/server';
import { db } from '@/db';
import { products } from '@/db/schema';
import { detectStoreFromUrl, calculateLandedCop, isProbablyUrl } from '@/lib/pricing';
import { getPricingConfig } from '@/lib/trm';
import { extractProductFromUrl } from '@/lib/scraper';
import { searchEncarguelo, searchGoogleFallback } from '@/lib/fallback-search';
import { toAmazonAffiliateUrl } from '@/lib/amazon-affiliate';
import { ensureDbSeeded } from '@/lib/init-db';

export async function POST(request: Request) {
  try {
    await ensureDbSeeded();
    const body = await request.json();
    const rawUrl = (body.url || '').trim();
    if (!rawUrl) return NextResponse.json({ success: false, error: 'Pega el enlace del artículo.' }, { status: 400 });

    let parsedUrl: URL;
    try {
      parsedUrl = new URL(rawUrl.startsWith('http') ? rawUrl : `https://${rawUrl}`);
      if (parsedUrl.pathname === '/' || parsedUrl.pathname.length < 3) {
        return NextResponse.json({ success: false, error: 'Ese enlace es la página principal de la tienda, no un artículo. Abre el producto y copia su enlace directo.' }, { status: 400 });
      }
    } catch {
      return NextResponse.json({ success: false, error: 'El enlace no es válido. Debe empezar por https://' }, { status: 400 });
    }

    const { storeKey, storeName } = detectStoreFromUrl(parsedUrl.href);
    const isEbay = storeKey === 'ebay';
    const sourceStoreUrl = parsedUrl.href;
    const config = await getPricingConfig();

    // 1) Extracción REAL en vivo (imagen, título, precio, peso empacado)
    let extracted = await extractProductFromUrl(parsedUrl.href);

    // 2) Coincidencia en catálogo
    let catalogMatch: any = null;
    try {
      const full = parsedUrl.href.toLowerCase();
      const asin = full.match(/\/dp\/([a-z0-9]{10})/i)?.[1];
      const ebayId = full.match(/\/itm\/([0-9]+)/)?.[1];
      const wmtId = full.match(/\/ip\/(?:[^/]+\/)?([0-9]{6,})/)?.[1];
      const bhId = full.match(/\/product\/([0-9]+)/)?.[1];
      const all = await db.select().from(products).limit(60);
      const reqPath = parsedUrl.pathname.toLowerCase().replace(/\/$/, '');
      let best = 0;
      for (const p of all) {
        const pu = p.storeUrl.toLowerCase();
        let s = 0;
        try { if (new URL(p.storeUrl).pathname.toLowerCase().replace(/\/$/, '') === reqPath) s += 40; } catch {}
        if (asin && pu.includes(asin.toLowerCase())) s += 30;
        if (ebayId && pu.includes(ebayId)) s += 30;
        if (wmtId && pu.includes(wmtId)) s += 30;
        if (bhId && pu.includes(bhId)) s += 30;
        if (s > best) { best = s; catalogMatch = p; }
      }
      if (best < 30) catalogMatch = null;
    } catch {}

    // 3) FALLBACK INTELIGENTE: Si no se pudo extraer imagen, título o precio de la tienda oficial,
    // buscar en encarguelo.com y luego en google.com
    let fallbackUsed = false;
    let fallbackSource: string | null = null;
    let officialStoreUrl: string | null = parsedUrl.href;

    const needsFallback = !extracted.imageUrl || !extracted.title || !extracted.priceUsd;
    if (needsFallback && !catalogMatch) {
      // Extraer ASIN o palabras clave de la URL para buscar
      const asinInUrl = parsedUrl.href.match(/(?:\/dp\/|\/gp\/product\/|product\/)([A-Z0-9]{10})/i)?.[1];
      const urlKeywords = parsedUrl.pathname
        .replace(/[-_/]/g, ' ')
        .replace(/\b(dp|product|ip|itm|html)\b/gi, ' ')
        .trim();

      // Para eBay, el id de 12 dígitos NO es un ASIN y nunca debe enviarse solo a Encárguelo:
      // podría devolver otro artículo diferente. Se usa el título extraído; si eBay lo bloquea,
      // solicitamos el precio/título al usuario antes de crear una cotización.
      const queryForSearch = asinInUrl || (isEbay ? extracted.title : urlKeywords);

      if (queryForSearch && !/^\d{8,}$/.test(queryForSearch.replace(/\s/g, ''))) {
        // Intento 1: Encárguelo.com
        const encargueloResult = await searchEncarguelo(queryForSearch);
        if (encargueloResult) {
          fallbackUsed = true;
          fallbackSource = 'encarguelo.com';
          if (!extracted.title && encargueloResult.title) extracted.title = encargueloResult.title;
          if (!extracted.imageUrl && encargueloResult.imageUrl) extracted.imageUrl = encargueloResult.imageUrl;
          if (encargueloResult.imageCandidates.length > 0) {
            extracted.imageCandidates = [...encargueloResult.imageCandidates, ...extracted.imageCandidates];
          }
          if (!extracted.priceUsd && encargueloResult.priceUsd) {
            extracted.priceUsd = encargueloResult.priceUsd;
            extracted.priceConfidence = 'high';
          }
          if (!extracted.weightLbs && encargueloResult.weightLbs) extracted.weightLbs = encargueloResult.weightLbs;
          if (encargueloResult.officialStoreUrl) officialStoreUrl = encargueloResult.officialStoreUrl;
        }

        // Intento 2: Google.com si todavía falta título o precio
        if (!extracted.title || !extracted.priceUsd) {
          const googleResult = await searchGoogleFallback(queryForSearch);
          if (googleResult) {
            fallbackUsed = true;
            fallbackSource = fallbackSource ? `${fallbackSource} + google.com` : 'google.com';
            if (!extracted.title && googleResult.title) extracted.title = googleResult.title;
            if (!extracted.priceUsd && googleResult.priceUsd) {
              extracted.priceUsd = googleResult.priceUsd;
              extracted.priceConfidence = 'high';
            }
            if (!extracted.imageUrl && googleResult.imageUrl) extracted.imageUrl = googleResult.imageUrl;
            if (googleResult.officialStoreUrl && (!officialStoreUrl || officialStoreUrl === parsedUrl.href)) {
              officialStoreUrl = googleResult.officialStoreUrl;
            }
          }
        }
      }
    }

    // Prioridad de datos. Nunca usar textos de errores/bloqueos de eBay como título del artículo.
    const rawTitle = catalogMatch?.title || extracted.title || null;
    const title = rawTitle && /^(error page|discover|sorry|something went wrong).*\|?\s*ebay/i.test(rawTitle.trim()) ? null : rawTitle;
    const priceUsd = catalogMatch
      ? Number(catalogMatch.priceUsd)
      : extracted.priceConfidence === 'high'
        ? extracted.priceUsd
        : null;
    const suggestedPriceUsd = !priceUsd && extracted.priceUsd ? extracted.priceUsd : null;
    const imageUrl = extracted.imageUrl || catalogMatch?.imageUrl || null;
    const weightLbs = catalogMatch ? Number(catalogMatch.weightLbs || 2) : extracted.weightLbs || 2;

    // El botón de tienda SIEMPRE debe dirigir a Amazon con el tag de afiliado.
    // Conservamos la URL original solo como referencia interna / informativa.
    const originalStoreUrl = catalogMatch?.storeUrl || officialStoreUrl || sourceStoreUrl;
    const amazonAffiliateUrl = title
      ? toAmazonAffiliateUrl(title, originalStoreUrl, catalogMatch?.sku || null)
      : toAmazonAffiliateUrl('productos importados', null, null);

    // Si tenemos título + precio, cotizamos
    if (title && priceUsd) {
      const landedFull = calculateLandedCop(priceUsd, weightLbs, config);
      return NextResponse.json({
        success: true,
        // `url` se usa en la interfaz para "VER EL ARTÍCULO EN TIENDA": siempre Amazon afiliado.
        url: amazonAffiliateUrl,
        amazonAffiliateUrl,
        originalStoreUrl,
        officialStoreUrl: amazonAffiliateUrl,
        store: catalogMatch?.store || storeName,
        storeKey,
        product: {
          title,
          priceUsd,
          imageUrl,
          imageCandidates: extracted.imageCandidates,
          imageIsReal: !!imageUrl,
          imageSource: fallbackUsed ? fallbackSource : extracted.source,
          weightLbs,
          brand: catalogMatch?.brand || storeName,
          description: catalogMatch?.description || `Artículo original de ${storeName}, importado por Personal Shopper V.I.P.`,
          features: catalogMatch?.features || [],
          stockStatus: extracted.source === 'direct' ? 'Verificado en la tienda oficial' : 'Verificado',
        },
        landed: { totalCop: landedFull.totalCop, deliveryEstimate: landedFull.deliveryEstimate },
        trm: config.usdToCop,
        trmSource: config.trmSource,
        trmUpdatedAt: config.trmUpdatedAt,
        note: fallbackUsed
          ? `Información y fotografía extraídas mediante respaldo en ${fallbackSource}.`
          : imageUrl
          ? 'Imagen real, peso empacado y precio extraídos del enlace.'
          : 'Precio verificado.',
      });
    }

    // Si falta el precio fiable -> pedir confirmación
    return NextResponse.json({
      success: false,
      requiresManualPrice: true,
      error: suggestedPriceUsd
        ? `Detectamos el artículo y su imagen real, pero la tienda requiere confirmación de precio. Vimos un precio de referencia de $${suggestedPriceUsd} USD: confírmalo o escribe el que ves en la tienda.`
        : isEbay
        ? 'eBay bloqueó la lectura automática de esta publicación. Para no generar una cotización errónea, indica el título y el precio USD visibles en eBay; buscaremos además su equivalente en Amazon con el enlace de afiliado.'
        : 'La tienda ocultó el precio de este artículo (variante o inicio de sesión). Indica el precio en USD que ves en la página y te damos el total exacto en Colombia.',
      detectedTitle: title,
      detectedImage: imageUrl,
      detectedImageCandidates: extracted.imageCandidates,
      suggestedPriceUsd,
      detectedStore: catalogMatch?.store || storeName,
      storeKey,
      // Aun si eBay no permitió extraer precio, la siguiente acción lleva al Amazon afiliado.
      url: title ? toAmazonAffiliateUrl(title, catalogMatch?.storeUrl || sourceStoreUrl, catalogMatch?.sku || null) : sourceStoreUrl,
      originalStoreUrl: catalogMatch?.storeUrl || sourceStoreUrl,
      officialStoreUrl: title ? toAmazonAffiliateUrl(title, catalogMatch?.storeUrl || sourceStoreUrl, catalogMatch?.sku || null) : sourceStoreUrl,
      weightLbs,
      trm: config.usdToCop,
      trmSource: config.trmSource,
    }, { status: 422 });
  } catch (err: any) {
    console.error('scrape-quote', err);
    return NextResponse.json({ success: false, error: err.message || 'Error al cotizar el enlace' }, { status: 500 });
  }
}
