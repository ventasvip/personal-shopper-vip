import { NextResponse } from 'next/server';
import { db } from '@/db';
import { products } from '@/db/schema';
import { ensureDbSeeded } from '@/lib/init-db';
import { ilike, or, eq, and, desc, asc } from 'drizzle-orm';
import { calculateLandedCop } from '@/lib/pricing';
import { toAmazonAffiliateUrl } from '@/lib/amazon-affiliate';
import { hasRelatedImage } from '@/lib/product-images';
import { getPricingConfig } from '@/lib/trm';

export async function GET(request: Request) {
  try {
    await ensureDbSeeded();
    const { searchParams } = new URL(request.url);
    const q = searchParams.get('q')?.trim() || '';
    const store = searchParams.get('store')?.trim() || '';
    const category = searchParams.get('category')?.trim() || '';
    const sort = searchParams.get('sort')?.trim() || 'popular';
    const config = await getPricingConfig();

    const conditions: any[] = [];
    if (q) conditions.push(or(ilike(products.title, `%${q}%`), ilike(products.description, `%${q}%`), ilike(products.brand, `%${q}%`), ilike(products.store, `%${q}%`), ilike(products.category, `%${q}%`)));
    if (store && store !== 'Todas') conditions.push(eq(products.store, store));
    if (category && category !== 'Todas') conditions.push(eq(products.category, category));

    const whereClause = conditions.length ? and(...conditions) : undefined;
    const orderClause = sort === 'price_asc' ? asc(products.priceUsd) : sort === 'price_desc' ? desc(products.priceUsd) : sort === 'rating' ? desc(products.rating) : desc(products.id);
    const items = await db.select().from(products).where(whereClause).orderBy(orderClause);

    // Recomendaciones: solo artículos con fotografía propia del artículo.
    const formatted = items.filter((p) => hasRelatedImage(p.imageUrl)).map((p) => {
      const priceUsd = Number(p.priceUsd);
      const weight = Number(p.weightLbs || 2);
      const landed = calculateLandedCop(priceUsd, weight, config);
      const originalStoreUrl = p.storeUrl;
      const amazonAffiliateUrl = toAmazonAffiliateUrl(p.title, originalStoreUrl, p.sku || null);
      // IMPORTACIONES VIP: al cliente solo se le expone el PRECIO TOTAL, sin desglose interno.
      // Todo enlace de tienda se convierte a Amazon con el tag de afiliado.
      return { ...p, priceUsd, originalPriceUsd: p.originalPriceUsd ? Number(p.originalPriceUsd) : null, weightLbs: weight, rating: Number(p.rating || 4.8), originalStoreUrl, amazonAffiliateUrl, storeUrl: amazonAffiliateUrl, landed: { totalCop: landed.totalCop, deliveryEstimate: landed.deliveryEstimate } };
    });

    return NextResponse.json({ success: true, items: formatted, total: formatted.length, trm: config.usdToCop, trmSource: config.trmSource, trmUpdatedAt: config.trmUpdatedAt, deliveryEstimate: '12 a 15 días hábiles' });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message || 'Error' }, { status: 500 });
  }
}
