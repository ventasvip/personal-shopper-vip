import { NextResponse } from 'next/server';
import { db } from '@/db';
import { products } from '@/db/schema';
import { ilike, or, eq, and } from 'drizzle-orm';
import { calculateLandedCop, detectStoreFromUrl, isProbablyUrl } from '@/lib/pricing';
import { getPricingConfig } from '@/lib/trm';
import { searchEncarguelo, searchGoogleFallback } from '@/lib/fallback-search';
import { toAmazonAffiliateUrl } from '@/lib/amazon-affiliate';
import { hasRelatedImage } from '@/lib/product-images';
import { ensureDbSeeded } from '@/lib/init-db';

export async function GET(request: Request) {
  try {
    await ensureDbSeeded();
    const { searchParams } = new URL(request.url);
    const qRaw = searchParams.get('q')?.trim() || '';
    const storeFilter = searchParams.get('store')?.trim() || '';
    const category = searchParams.get('category')?.trim() || '';
    const sort = searchParams.get('sort')?.trim() || 'relevant';
    if (!qRaw) return NextResponse.json({ success: true, items: [], total: 0, mode: 'empty' });

    const config = await getPricingConfig();
    const publicLanded = (price: number, weight: number) => {
      const l = calculateLandedCop(price, weight, config);
      return { totalCop: l.totalCop, deliveryEstimate: l.deliveryEstimate };
    };

    // Si pegaron una URL en el buscador de texto
    if (isProbablyUrl(qRaw)) {
      return NextResponse.json({
        success: true,
        mode: 'url',
        isUrl: true,
        query: qRaw,
        storeHint: detectStoreFromUrl(qRaw).storeName,
        items: [],
        total: 0,
        message: 'Detectamos un enlace. Lo cotizaremos directamente desde la tienda.',
      });
    }

    const synonymMap: Record<string, string[]> = {
      ps5: ['playstation', 'ps5'],
      ps4: ['playstation'],
      xbox: ['xbox', 'microsoft'],
      iphone: ['iphone', 'apple'],
      ipad: ['ipad', 'apple'],
      macbook: ['macbook', 'apple'],
      airpods: ['airpods', 'apple'],
      kindle: ['kindle', 'amazon'],
      gopro: ['gopro'],
      dji: ['dji'],
      steam: ['steam', 'valve'],
    };
    const searchTerms = qRaw.toLowerCase().split(/\s+/).filter((t) => t.length >= 2);
    const termConditions: any[] = [];
    for (const rawTerm of searchTerms) {
      for (const term of synonymMap[rawTerm] || [rawTerm]) {
        termConditions.push(
          or(
            ilike(products.title, `%${term}%`),
            ilike(products.description, `%${term}%`),
            ilike(products.brand, `%${term}%`),
            ilike(products.category, `%${term}%`),
            ilike(products.store, `%${term}%`),
            ilike(products.sku, `%${term}%`)
          )
        );
      }
    }
    const extra: any[] = [];
    if (storeFilter && storeFilter !== 'Todas') extra.push(eq(products.store, storeFilter));
    if (category && category !== 'Todas') extra.push(eq(products.category, category));
    const whereClause = termConditions.length
      ? extra.length
        ? and(or(...termConditions), ...extra)
        : or(...termConditions)
      : extra.length
      ? and(...extra)
      : undefined;

    const candidates = await db.select().from(products).where(whereClause).limit(60);
    const scored = candidates.map((p) => {
      const hay = `${p.title} ${p.description} ${p.brand} ${p.category} ${p.sku}`.toLowerCase();
      let score = 0;
      for (const term of searchTerms) {
        for (const syn of synonymMap[term] || [term]) {
          if (hay.includes(syn)) {
            score += 2;
            if (p.title.toLowerCase().includes(syn)) score += 3;
          }
        }
      }
      if (hay.includes(qRaw.toLowerCase())) score += 10;
      return { p, score };
    });
    scored.sort(
      (a, b) =>
        b.score - a.score ||
        (sort === 'price_asc'
          ? Number(a.p.priceUsd) - Number(b.p.priceUsd)
          : sort === 'price_desc'
          ? Number(b.p.priceUsd) - Number(a.p.priceUsd)
          : 0)
    );
    let finalList = scored.filter((s) => s.score > 0).slice(0, 30).map((s) => s.p);

    // FALLBACK INTELIGENTE EN BÚSQUEDA POR NOMBRE:
    // Si no hay resultados locales en el catálogo, buscar en encarguelo.com y Google
    let fallbackInfo: string | null = null;
    if (finalList.length === 0) {
      // 1) Buscar en encarguelo.com
      const encItem = await searchEncarguelo(qRaw);
      if (encItem && encItem.title && hasRelatedImage(encItem.imageUrl)) {
        fallbackInfo = 'encarguelo.com';
        const price = encItem.priceUsd || 199.99;
        const weight = encItem.weightLbs || 2.0;
        finalList.push({
          id: 999001,
          title: encItem.title || qRaw,
          description: `Artículo original localizado mediante encarguelo.com.`,
          priceUsd: price.toString(),
          originalPriceUsd: null,
          store: encItem.officialStoreUrl ? detectStoreFromUrl(encItem.officialStoreUrl).storeName : 'Amazon',
          storeUrl: encItem.officialStoreUrl || `https://www.amazon.com/s?k=${encodeURIComponent(qRaw)}`,
          imageUrl: encItem.imageUrl,
          category: 'Tecnología',
          rating: '4.8',
          reviewsCount: 150,
          weightLbs: weight.toString(),
          inStock: true,
          sku: null,
          brand: 'Original USA',
          features: ['Extraído con respaldo en encarguelo.com', 'Fotografía original y peso empacado'],
          createdAt: new Date(),
        } as any);
      } else {
        // 2) Buscar en Google.com
        const googItem = await searchGoogleFallback(qRaw);
        if (googItem && googItem.title && hasRelatedImage(googItem.imageUrl)) {
          fallbackInfo = 'google.com';
          const price = googItem.priceUsd || 199.99;
          const weight = googItem.weightLbs || 2.0;
          const storeName = googItem.officialStoreUrl ? detectStoreFromUrl(googItem.officialStoreUrl).storeName : 'Amazon';
          finalList.push({
            id: 999002,
            title: googItem.title || qRaw,
            description: `Artículo localizado en tienda oficial ${storeName} vía Google.`,
            priceUsd: price.toString(),
            originalPriceUsd: null,
            store: storeName,
            storeUrl: googItem.officialStoreUrl || `https://www.google.com/search?q=${encodeURIComponent(qRaw)}`,
            imageUrl: googItem.imageUrl,
            category: 'Tecnología',
            rating: '4.8',
            reviewsCount: 120,
            weightLbs: weight.toString(),
            inStock: true,
            sku: null,
            brand: storeName,
            features: ['Localizado en tienda oficial vía Google'],
            createdAt: new Date(),
          } as any);
        }
      }
    }

    // Solo artículos con fotografía propia del artículo.
    finalList = finalList.filter((p) => hasRelatedImage(p.imageUrl));

    const formatted = finalList.map((p) => {
      const priceUsd = Number(p.priceUsd);
      const weight = Number(p.weightLbs || 2);
      const originalStoreUrl = p.storeUrl;
      // Todas las tarjetas/resultados llevan a Amazon Associates, incluso si la fuente fue eBay/B&H/Walmart.
      const amazonAffiliateUrl = toAmazonAffiliateUrl(p.title, originalStoreUrl, p.sku || null);
      return {
        ...p,
        priceUsd,
        originalPriceUsd: p.originalPriceUsd ? Number(p.originalPriceUsd) : null,
        weightLbs: weight,
        rating: Number(p.rating || 4.8),
        originalStoreUrl,
        amazonAffiliateUrl,
        storeUrl: amazonAffiliateUrl,
        landed: publicLanded(priceUsd, weight),
      };
    });
    const byStore: Record<string, number> = {};
    formatted.forEach((i: any) => {
      byStore[i.store] = (byStore[i.store] || 0) + 1;
    });

    return NextResponse.json({
      success: true,
      mode: 'keyword',
      query: qRaw,
      items: formatted,
      total: formatted.length,
      byStore,
      fallbackUsed: !!fallbackInfo,
      fallbackSource: fallbackInfo,
      trm: config.usdToCop,
      trmSource: config.trmSource,
      trmUpdatedAt: config.trmUpdatedAt,
      deliveryEstimate: '12 a 15 días hábiles',
      message: formatted.length
        ? fallbackInfo
          ? `Localizamos opciones para "${qRaw}" mediante respaldo en ${fallbackInfo}. Precio total en pesos.`
          : `Encontramos ${formatted.length} opción(es) para "${qRaw}" en Amazon, eBay, B&H Photo, Adorama y Walmart. Precio total puesto en Colombia.`
        : `No hallamos "${qRaw}" en el catálogo. Pega el enlace del artículo o cotízalo con su precio en USD.`,
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message || 'Error en búsqueda' }, { status: 500 });
  }
}
