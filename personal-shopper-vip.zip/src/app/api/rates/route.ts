import { NextResponse } from 'next/server';
import { fetchLiveTRM } from '@/lib/trm';

// Compatibilidad: la TRM ya NO es manual, es automática. Este endpoint devuelve la TRM en vivo.
export async function GET() {
  const trm = await fetchLiveTRM();
  return NextResponse.json({ success: true, trm: trm.rate, rate: trm.rate, source: trm.source, updatedAt: trm.updatedAt, automatic: true });
}
export async function POST() {
  const trm = await fetchLiveTRM(true);
  return NextResponse.json({ success: true, trm: trm.rate, source: trm.source, updatedAt: trm.updatedAt, automatic: true, message: 'TRM automática actualizada. No requiere ajuste manual.' });
}
