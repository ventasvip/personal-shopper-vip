import { NextResponse } from 'next/server';
import { db } from '@/db';
import { quotes } from '@/db/schema';
import { desc } from 'drizzle-orm';
import { calculateLandedCop } from '@/lib/pricing';
import { getPricingConfig } from '@/lib/trm';

export async function GET() {
  try {
    const list = await db.select().from(quotes).orderBy(desc(quotes.id)).limit(50);
    return NextResponse.json({ success: true, quotes: list });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message || 'Error' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { sourceUrl, detectedStore, itemTitle, itemPriceUsd, itemImageUrl, weightLbs, customerEmail, customerPhone, customerCity, notes } = body;
    if (!sourceUrl || !itemTitle || !itemPriceUsd) return NextResponse.json({ success: false, error: 'Faltan datos del artículo' }, { status: 400 });

    const config = await getPricingConfig();
    const priceNum = parseFloat(itemPriceUsd);
    const weightNum = Math.max(0.5, parseFloat(weightLbs || '2') || 2);
    const landed = calculateLandedCop(priceNum, weightNum, config);

    const [saved] = await db.insert(quotes).values({
      sourceUrl, detectedStore: detectedStore || 'Tienda USA', itemTitle,
      itemPriceUsd: priceNum.toString(), itemImageUrl: itemImageUrl || null,
      weightLbs: weightNum.toString(), calculatedCop: landed.totalCop.toString(),
      exchangeRate: config.usdToCop.toString(),
      shippingCop: '0', customsTaxCop: '0', handlingFeeCop: '0', // interno: no se expone desglose al cliente
      status: 'cotizado', customerEmail: customerEmail || null, customerPhone: customerPhone || null, customerCity: customerCity || null, notes: notes || null,
    }).returning();

    return NextResponse.json({ success: true, quote: saved, landed: { totalCop: landed.totalCop, deliveryEstimate: landed.deliveryEstimate }, trm: config.usdToCop });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message || 'Error al guardar' }, { status: 500 });
  }
}
