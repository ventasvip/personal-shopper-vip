'use client';

import React, { useState, useEffect } from 'react';
import { Search, Sparkles, Crown, Camera, Laptop, Gamepad2, Tv, Layers, RefreshCcw, SlidersHorizontal, ArrowLeft, Package, Clock3, ShieldCheck, Globe2 } from 'lucide-react';
import { UnifiedSearchBar } from '@/components/UnifiedSearchBar';
import { ProductCard, ProductItem } from '@/components/ProductCard';
import { QuoteBreakdownModal } from '@/components/QuoteBreakdownModal';
import { TrmBadge } from '@/components/TrmBadge';
import { StoreLogos } from '@/components/StoreLogos';
import { ShippingAndPayments } from '@/components/ShippingAndPayments';
import { TermsAndConditions, TermsButton } from '@/components/TermsAndConditions';
import { ManualQuotePrompt } from '@/components/ManualQuotePrompt';
import { formatCOP } from '@/lib/pricing';

const CATEGORIES = [
  { id: 'Todas', name: 'Todo', icon: Layers },
  { id: 'Cámaras y Lentes', name: 'Cámaras & Óptica', icon: Camera },
  { id: 'Audio & Video', name: 'Audio & Video', icon: Tv },
  { id: 'Laptops & Cómputo', name: 'Cómputo & Celulares', icon: Laptop },
  { id: 'Gaming', name: 'Gaming', icon: Gamepad2 },
  { id: 'Drones & Gadgets', name: 'Drones & Gadgets', icon: Sparkles },
];

export default function HomePage() {
  const [catalog, setCatalog] = useState<ProductItem[]>([]);
  const [loadingCatalog, setLoadingCatalog] = useState(true);
  const [trm, setTrm] = useState<number | null>(null);
  const [selectedCategory, setSelectedCategory] = useState('Todas');
  const [selectedSort, setSelectedSort] = useState('popular');
  const [searchMode, setSearchMode] = useState<'catalog' | 'search'>('catalog');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any | null>(null);
  const [activeQuote, setActiveQuote] = useState<any>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  // Artículos cuya foto no carga: se ocultan para no mostrar tarjetas sin imagen del artículo.
  const [brokenImageIds, setBrokenImageIds] = useState<Set<number>>(new Set());
  const [isTermsOpen, setIsTermsOpen] = useState(false);

  const fetchCatalog = async () => {
    setLoadingCatalog(true);
    try {
      const params = new URLSearchParams();
      if (selectedCategory !== 'Todas') params.set('category', selectedCategory);
      if (selectedSort) params.set('sort', selectedSort);
      const res = await fetch(`/api/products?${params.toString()}`);
      const data = await res.json();
      if (data.success) { setCatalog(data.items); if (data.trm) setTrm(data.trm); }
    } catch {} finally { setLoadingCatalog(false); }
  };

  useEffect(() => { if (searchMode === 'catalog') fetchCatalog(); }, [selectedCategory, selectedSort, searchMode]);
  useEffect(() => { fetch('/api/trm').then(r => r.json()).then(j => { if (j.success) setTrm(j.trm); }).catch(() => {}); }, []);

  const handleKeywordResults = (data: any) => { setSearchResults(data); setSearchQuery(data.query || ''); setSearchMode('search'); if (data.trm) setTrm(data.trm); window.scrollTo({ top: 430, behavior: 'smooth' }); };
  const handleUrlQuote = (data: any) => { setActiveQuote({ url: data.url, store: data.store, product: data.product, landed: data.landed, trm: data.trm }); setIsModalOpen(true); };
  const clearSearch = () => { setSearchMode('catalog'); setSearchResults(null); setSearchQuery(''); };
  const openProduct = (p: ProductItem) => { setActiveQuote({ url: p.storeUrl, store: p.store, product: { title: p.title, description: p.description, priceUsd: p.priceUsd, imageUrl: p.imageUrl, weightLbs: p.weightLbs, brand: p.brand || undefined, features: p.features || undefined, sku: p.sku || undefined }, landed: p.landed, trm }); setIsModalOpen(true); };

  // Abrir cotización directa al seleccionar un resultado del desplegable
  const handleResultSelect = (item: any) => {
    setActiveQuote({
      url: item.storeUrl || null,
      store: item.store,
      product: {
        title: item.title,
        description: item.description || '',
        priceUsd: item.priceUsd,
        imageUrl: item.imageUrl,
        weightLbs: item.weightLbs,
        brand: item.brand || undefined,
        features: item.features || undefined,
        sku: item.sku || undefined,
      },
      landed: item.landed || { totalCop: 0, deliveryEstimate: '12 a 15 días hábiles' },
      trm: item.trm,
    });
    setIsModalOpen(true);
  };

  const hideBrokenImage = (id: number) => setBrokenImageIds((prev) => (prev.has(id) ? prev : new Set(prev).add(id)));
  const sourceItems: ProductItem[] = searchMode === 'search' && searchResults?.items ? searchResults.items : catalog;
  const display: ProductItem[] = sourceItems.filter((item) => item.imageUrl && !brokenImageIds.has(item.id));
  const loading = searchMode === 'search' ? false : loadingCatalog;

  return (
    <div className="min-h-screen bg-black text-zinc-100 flex flex-col font-sans selection:bg-amber-400 selection:text-black">
      {/* Barra superior VIP */}
      <div className="bg-amber-400 text-black px-4 py-2 text-center text-[11px] sm:text-xs font-black tracking-wide flex items-center justify-center gap-2">
        <Crown className="w-4 h-4" /> Personal Shopper V.I.P · Precio total puesto en Colombia · Entrega en 12 a 15 días hábiles · Sin pagos adicionales al recibir
      </div>

      <header className="sticky top-0 z-40 bg-black/85 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-[72px] flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-11 h-11 rounded-2xl bg-amber-400 flex items-center justify-center shrink-0 shadow-lg shadow-amber-400/20"><Crown className="w-6 h-6 text-black" /></div>
            <div className="min-w-0">
              <div className="text-lg sm:text-xl font-black tracking-tight leading-none text-white">Personal Shopper <span className="text-amber-400">V.I.P</span></div>
              <p className="text-[10px] sm:text-[11px] text-zinc-400 mt-1 truncate">Amazon · B&H Photo · Adorama · Walmart · eBay → Colombia</p>
            </div>
          </div>
          <TrmBadge />
        </div>
        <nav aria-label="Información del servicio" className="max-w-7xl mx-auto flex justify-end px-4 pb-3 sm:px-6">
          <TermsButton onClick={() => setIsTermsOpen(true)} />
        </nav>
      </header>

      {/* Hero (Opción A: buscador protagonista) */}
      <section className="relative px-4 sm:px-6 pt-10 pb-10 sm:pt-14 overflow-hidden">
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-[700px] h-[380px] bg-amber-400/10 blur-[130px] rounded-full pointer-events-none" />
        <div className="relative max-w-4xl mx-auto text-center space-y-4">
          <span className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/5 border border-amber-400/30 text-[11px] font-bold text-amber-300"><Globe2 className="w-3.5 h-3.5" /> Compramos por ti en las tiendas oficiales de USA</span>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight text-white leading-[1.08] text-balance">
            <span className="block">Busca el artículo en las tiendas recomendadas</span>
            <span className="sr-only"> - </span>
            <span className="block text-amber-400">Pega el enlace y Descubre su precio final todo incluido.</span>
          </h1>
          <p className="text-zinc-400 text-sm sm:text-base max-w-2xl mx-auto">No somos una tienda ni un casillero convencional, somos un servicio personalizado de compra por encargo y transporte desde tiendas en los Estados Unidos a Colombia. Entrega a tu puerta en <b className="text-amber-300">12 a 15 días hábiles</b>. Asesoría Personalizada.</p>
          <div className="pt-2">
            <UnifiedSearchBar onKeywordResults={handleKeywordResults} onUrlQuote={handleUrlQuote} onUrlRequiresManual={() => {}} onResultSelect={handleResultSelect} />
          </div>
          {searchMode === 'search' && (
            <button onClick={clearSearch} className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-bold cursor-pointer"><ArrowLeft className="w-4 h-4" /> Volver al catálogo VIP</button>
          )}
        </div>
      </section>

      <StoreLogos />

      <aside aria-labelledby="service-terms-notice" className="max-w-7xl mx-auto w-full px-4 pb-8 sm:px-6">
        <div className="flex flex-col gap-4 rounded-2xl border border-amber-400/25 bg-amber-400/5 p-4 sm:flex-row sm:items-center sm:justify-between sm:p-5">
          <div className="max-w-3xl">
            <h2 id="service-terms-notice" className="text-sm font-bold text-amber-300">Antes de solicitar tu compra por encargo</h2>
            <p className="mt-1 text-xs leading-relaxed text-zinc-300 sm:text-sm">Actuamos como intermediarios de compra y operadores logísticos, no como tienda vendedora de equipos. Consulta el alcance del servicio y las condiciones de pagos, seguros, garantías, devoluciones y reemplazos.</p>
          </div>
          <div className="shrink-0"><TermsButton label="Leer condiciones del servicio" onClick={() => setIsTermsOpen(true)} /></div>
        </div>
      </aside>

      {searchMode === 'search' && searchResults && (
        <div className="max-w-7xl mx-auto w-full px-4 sm:px-6">
          <div className="rounded-3xl bg-zinc-900 border border-amber-400/25 p-4 sm:p-5 mb-6 flex flex-col sm:flex-row justify-between gap-3">
            <div className="flex gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-400 text-black flex items-center justify-center shrink-0"><Search className="w-5 h-5" /></div>
              <div>
                <h2 className="font-black text-white">{searchResults.total > 0 ? `${searchResults.total} opción(es) para “${searchResults.query}”` : `Resultados para “${searchResults.query}”`}</h2>
                <p className="text-xs text-zinc-400 mt-0.5">{searchResults.message}</p>
                {searchResults.byStore && searchResults.total > 0 && <div className="flex flex-wrap gap-1.5 mt-2">{Object.entries(searchResults.byStore).map(([s, c]) => <span key={s} className="text-[11px] px-2 py-0.5 rounded-full bg-black border border-white/10">{s}: <b className="text-amber-300">{c as number}</b></span>)}</div>}
              </div>
            </div>
            <div className="text-[11px] text-zinc-400 bg-black/50 border border-white/10 rounded-xl px-3 py-2 h-fit shrink-0">
              <div className="flex items-center gap-1 font-bold text-zinc-200"><Package className="w-3.5 h-3.5 text-amber-300" /> Precio total puesto en Colombia</div>
              <div className="mt-0.5">Entrega: 12 a 15 días hábiles{trm ? <> · TRM hoy {formatCOP(trm)}</> : null}</div>
            </div>
          </div>
        </div>
      )}

      <section className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 pb-16">
        <div className="flex items-center gap-2 overflow-x-auto pb-3 border-b border-white/10 scrollbar-none">
          {CATEGORIES.map(cat => { const Icon = cat.icon; const sel = selectedCategory === cat.id; return (
            <button key={cat.id} onClick={() => setSelectedCategory(cat.id)} className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap cursor-pointer ${sel ? 'bg-amber-400 text-black' : 'bg-zinc-900 text-zinc-300 border border-white/10 hover:bg-zinc-800'}`}><Icon className="w-4 h-4" />{cat.name}</button> ); })}
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mt-5 mb-6">
          <h2 className="flex items-center gap-2 text-xl sm:text-2xl font-black text-white">
            <Sparkles className="w-5 h-5 text-amber-400" aria-hidden="true" />
            {searchMode === 'search' ? 'Resultados de tu búsqueda' : 'Recomendaciones del día'}
          </h2>
          <div className="flex items-center gap-3 justify-between sm:justify-end">
            <span className="text-xs text-zinc-500"><b className="text-amber-300">{display.length}</b> artículos</span>
            <label className="flex items-center gap-2 bg-zinc-900 border border-white/10 px-3 py-1.5 rounded-xl text-xs"><SlidersHorizontal className="w-3.5 h-3.5 text-zinc-400" /><select value={selectedSort} onChange={e => setSelectedSort(e.target.value)} className="bg-transparent text-zinc-200 focus:outline-none cursor-pointer"><option value="popular" className="bg-zinc-900">Relevancia</option><option value="price_asc" className="bg-zinc-900">Menor precio total</option><option value="price_desc" className="bg-zinc-900">Mayor precio total</option><option value="rating" className="bg-zinc-900">Mejor valorados</option></select></label>
          </div>
        </div>

        {loading ? (
          <div className="py-16 text-center"><RefreshCcw className="w-8 h-8 text-amber-300 animate-spin mx-auto" /><p className="text-zinc-400 text-sm mt-3">Cargando artículos con precio total en Colombia…</p></div>
        ) : display.length === 0 ? (
          <div className="py-8 bg-zinc-900/60 rounded-[28px] border border-white/10 p-6 sm:p-8">
            <div className="text-center">
              <div className="w-14 h-14 rounded-full bg-zinc-800 flex items-center justify-center mx-auto"><Search className="w-7 h-7 text-zinc-500" /></div>
              <h3 className="text-lg font-black mt-3">{searchMode === 'search' ? `No hallamos “${searchQuery}” en el catálogo` : 'Sin artículos con esos filtros'}</h3>
              <p className="text-xs sm:text-sm text-zinc-400 max-w-lg mx-auto mt-2">Pega arriba el enlace del artículo en su tienda o cotízalo aquí con su precio en USD — te damos el total exacto, sin inventar valores.</p>
              <button onClick={clearSearch} className="mt-4 px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-xs font-bold cursor-pointer">Ver catálogo completo</button>
            </div>
            {searchMode === 'search' && searchQuery && <ManualQuotePrompt query={searchQuery} onQuoteGenerated={(data) => { setActiveQuote({ url: data.url, store: data.store, product: data.product, landed: data.landed, trm: data.trm }); setIsModalOpen(true); }} />}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {display.map(item => <ProductCard key={item.id} product={item} onSelect={openProduct} onInstantOrder={openProduct} onImageError={hideBrokenImage} />)}
          </div>
        )}

        {/* Cómo funciona — sin desglose de cargos */}
        <div className="mt-14 bg-zinc-900/70 border border-white/10 rounded-[28px] p-6 sm:p-8">
          <div className="text-center max-w-xl mx-auto mb-7">
            <h3 className="text-xl sm:text-2xl font-black">Así de simple funciona <span className="text-amber-400">Personal Shopper V.I.P</span></h3>
            <p className="text-xs sm:text-sm text-zinc-400 mt-1">Un solo precio final. Lo ves, lo pides y lo recibes en tu puerta.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { n: '1', t: 'Busca o pega el enlace', d: 'Escribe el nombre del artículo o pega su link de Amazon, B&H Photo, Adorama, Walmart o eBay. Extraemos su imagen real y su precio.' },
              { n: '2', t: 'Mira el precio total', d: 'Te mostramos un único precio en pesos colombianos, puesto en tu ciudad. Ese es el valor final de tu pedido.' },
              { n: '3', t: 'Recíbelo en 12 a 15 días hábiles', d: 'Confirmas tu solicitud, compramos el artículo original en USA y te lo entregamos en cualquier ciudad de Colombia.' },
            ].map(s => (
              <div key={s.n} className="bg-black/50 p-5 rounded-2xl border border-white/10">
                <div className="w-9 h-9 rounded-xl bg-amber-400 text-black flex items-center justify-center font-black">{s.n}</div>
                <h4 className="font-black text-sm mt-3">{s.t}</h4><p className="text-xs text-zinc-400 leading-relaxed mt-1">{s.d}</p>
              </div>
            ))}
          </div>
          <div className="mt-5 flex flex-wrap justify-center gap-2 text-[11px]">
            <span className="inline-flex items-center gap-1.5 bg-black/50 border border-white/10 rounded-full px-3 py-1.5"><ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Compra en tienda oficial</span>
            <span className="inline-flex items-center gap-1.5 bg-black/50 border border-white/10 rounded-full px-3 py-1.5"><Clock3 className="w-3.5 h-3.5 text-amber-300" /> 12 a 15 días hábiles</span>
            <span className="inline-flex items-center gap-1.5 bg-black/50 border border-white/10 rounded-full px-3 py-1.5"><Sparkles className="w-3.5 h-3.5 text-amber-300" /> TRM automática del día</span>
          </div>
        </div>
      </section>

      <ShippingAndPayments />

      <footer className="border-t border-white/10 py-7 px-4 text-[11px] text-zinc-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <span className="flex items-center gap-2 text-zinc-300 font-bold"><Crown className="w-4 h-4 text-amber-400" /> Personal Shopper V.I.P · USA → Colombia</span>
          <span>Amazon · B&H Photo NYC · Adorama · Walmart · eBay</span>
          <span>{trm ? `TRM hoy: 1 USD = ${formatCOP(trm)}` : 'TRM automática'} · Entrega 12 a 15 días hábiles</span>
        </div>
        <nav aria-label="Información legal" className="max-w-7xl mx-auto mt-5 flex justify-center">
          <TermsButton onClick={() => setIsTermsOpen(true)} />
        </nav>
      </footer>

      <TermsAndConditions isOpen={isTermsOpen} onClose={() => setIsTermsOpen(false)} />
      <QuoteBreakdownModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} quoteData={activeQuote} />
    </div>
  );
}
