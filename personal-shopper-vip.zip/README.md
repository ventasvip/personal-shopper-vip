# Personal Shopper V.I.P

Aplicación completa con Next.js App Router, PostgreSQL y Drizzle ORM.

## Corrección del error de Vercel «Couldn't find any pages or app directory»

Se revisó el repositorio público `ventasvip/personal-shopper-vip`, commit `6f76e91`, que aparece en el registro de Vercel. Los archivos de la aplicación se subieron **todos en la raíz, sin conservar sus carpetas**. Por eso Next.js no detecta la aplicación. Esto no se soluciona esperando el DNS ni cambiando el dominio.

En este paquete la estructura es correcta. En la raíz de tu repositorio deben verse:

- `package.json` y `package-lock.json`
- `next.config.ts`, `tsconfig.json`, `postcss.config.mjs` y `vercel.json`
- `drizzle.config.ts`
- `src/app/page.tsx`, `src/app/layout.tsx` y `src/app/globals.css`
- `src/app/api/health/route.ts` y las otras rutas de API, **cada una en su carpeta propia**
- `src/components/`, `src/lib/` y `src/db/`
- `public/images/` y `public/logos/`

`page.tsx` y `layout.tsx` no deben estar sueltos en la raíz. Tampoco deben combinarse todas las rutas de API en un único `route.ts`: hay varios archivos con ese nombre en carpetas diferentes.

### ¿Hay carpetas dentro de carpetas?

Sí: es normal y necesario. No separes ni aplanes las carpetas internas. `src` contiene `app`, `components`, `lib` y `db`; dentro de `app` están las páginas y sus distintas carpetas de API. `public` contiene `images` y `logos`.

La carpeta que contiene **juntos `package.json`, `src` y `public`** es la raíz de la aplicación. Algunos programas crean una carpeta exterior al descomprimir el ZIP: entra en ella hasta ver esos tres elementos juntos. Sube el contenido de ese nivel al repositorio conservando las carpetas completas, no solamente los archivos que hay dentro de ellas.

Si esos tres elementos quedan directamente en la raíz de GitHub, deja **Root Directory vacío o `.`** en Vercel. Si el proyecto se sube deliberadamente dentro de una carpeta exterior, Root Directory debe ser la ruta exacta de ESA carpeta, la que contiene `package.json` y `src`, no `src/app`. No es necesario añadir una carpeta exterior para este proyecto.

Las carpetas que ves en tu computador no prueban que ya estén en GitHub: abre el repositorio en el navegador y comprueba la ruta `src` → `app` → `page.tsx`. Después guarda los cambios con **Commit changes** (o commit y push si usas un cliente de Git). Vercel debe compilar ese nuevo commit; volver a desplegar el commit anterior conserva el mismo problema.

### Cómo volver a subirlo

1. Haz una copia del repositorio anterior si necesitas conservarla.
2. Descomprime el ZIP del proyecto. **No subas solo el ZIP a GitHub**: Vercel no lo descomprimirá como aplicación.
3. Reemplaza el contenido de la copia local del repositorio por los archivos y carpetas de este paquete. Conserva la carpeta `.git` de tu copia local, si existe. No mezcles el proyecto corregido con los archivos sueltos de la carga anterior.
4. Al subirlo a GitHub, conserva las carpetas `src` y `public` completas. Comprueba en GitHub que se puede abrir `src` → `app` → `page.tsx` y que se ven todas las subcarpetas de `src/app/api`.
5. En Vercel, selecciona ese repositorio y la rama `main`. La nueva publicación debe usar el **commit corregido**, no volver a compilar `6f76e91`.

### Configuración del proyecto en Vercel

- **Framework Preset:** Next.js.
- **Root Directory:** raíz del repositorio (campo vacío o `.`), si allí está `package.json`. No uses `src`, `src/app` ni el nombre de un archivo como raíz.
- **Build Command:** `npm run build`.
- **Output Directory:** deja la configuración automática de Next.js, sin personalizarla.
- **Install Command:** automático. El paquete incluye el lockfile.
- **Environment Variables:** configura `DATABASE_URL` con una base PostgreSQL persistente y `NEXT_PUBLIC_SITE_URL` con `https://traigalodeusa.com`. No uses la dirección `127.0.0.1` de otro entorno como base de Vercel.

Prepara las tablas de la base de producción con `npx drizzle-kit push --config=drizzle.config.ts` desde un terminal de confianza con la variable `DATABASE_URL` correcta. Revisa los cambios antes de aplicarlos a una base con información existente. Consulta `DEPLOYMENT.md` para los pasos de dominio, HTTPS y acceso público.

Tras guardar los cambios en GitHub, Vercel debe crear una publicación nueva. El ZIP y esta guía **no hacen cambios automáticos en tu cuenta de GitHub, Vercel o GoDaddy**.

## Comprobaciones del proyecto

- `npx next typegen`
- `npm exec tsc -- --noEmit --pretty false`
- `npm run build`

Una vez publicado, comprueba la página principal y `/api/health`. El último debe responder HTTP 200 con `{"ok":true}` antes de dar por lista la conexión con la base de datos.

## Protección de credenciales

Solo se incluye `.env.example`, con valores ficticios. Configura tus credenciales fuera del repositorio. Nunca subas `.env`, contraseñas o tokens. La carpeta `.vercel` tampoco se comparte.

## Exportación del proyecto

Desde la raíz puedes ejecutar `python3 scripts/package-project.py`. Genera `public/descargas/personal-shopper-vip.zip` con una lista explícita de carpetas y archivos permitidos. La exportación omite credenciales, dependencias, compilaciones y la propia carpeta de descargas. El resultado conserva todas las rutas, sin aplanarlas. El ZIP es una exportación de código, **no** una copia de los datos de PostgreSQL.
